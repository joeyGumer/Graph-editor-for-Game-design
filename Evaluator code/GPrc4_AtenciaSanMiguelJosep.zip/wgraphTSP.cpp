#include "wgraph.h"

bool HamiltonianCycle(wgraph& G, ofstream& fout)
{
	return false;
}
index HamiltonianCycles(wgraph& G, ofstream& fout)
{
	return 0;
}
weight TravellingSalesmanProblem(wgraph& G, ofstream& fout)
{
	vertex vn = G.size();

	if (vn <= 2)
		return 0;

	vector<vertex> HCv;
	vector<bool> HCl(vn, false);
	vector<index> ind(vn, 0);
	vector<vertex> minimal_HCv;
	weight cycle_w = UINT_MAX;

	vertex rv = 0;
	HCv.push_back(rv);
	HCl[rv] = true;

	vertex v = rv;
	index nrv = G[rv].size();
	bool cycle = false;
	while (true)
	{
		if (ind[v] < G[v].size())
		{
			v = G[v][ind[v]++].first;

			if (HCl[v] == false)
			{
				//Next vertex is not visited
				HCv.push_back(v);
				HCl[v] = true;
			}
			else if (v == rv && HCv.size() == vn)
			{
				//We found a Hamiltonian cycle
				//check the weight
				weight w = 0;
				vertex u = 0;
				for (index i = 0; i < vn - 1; i++)
				{
					u = HCv[i];
					w += G[u][ind[u] - 1].second;
				}
				u = HCv.back();
				w += G[u][ind[u] - 1].second;

				if (w < cycle_w)
				{
					cycle_w = w;
					minimal_HCv = HCv;
				}

				cycle = true;

				//Backtrack to find other cycles
				v = HCv.back();
			}
			else //Vertex already visited and is not the root, backtrack
				v = HCv.back();
		}
		else
		{
			//If the vertex with no more neighbours to check is the root
			//we have checked all possible hamiltonian cycles, end while
			if (v == rv)
				break;

			//No more neighbours to check, reset the vertex info and backtrack
			HCv.pop_back();
			ind[v] = 0;
			HCl[v] = false;
			v = HCv.back();
		}
	}

	if (cycle)
	{
		fout << "Minimal Hamiltonian cycle with weight ( " << cycle_w << " ): " << rv;
		for (index i = 1; i < vn; i++)
			fout << "-" << minimal_HCv[i];
		fout << endl;

	}
	else
		fout << "There's no Hamiltonian cycle\n";

	return cycle_w;
}