#include <ctime>
#include "graph.h"
#include "wgraph.h"
#include "graphe.h"

 int 
	main()
{
    ofstream fout;
//  Seed rand()
    srand( (unsigned int) time( NULL ) ) ;
    vertex mv = 8;
    vertex n = rand() % mv + 1;
    vertex n1 = rand() % mv + 1;
    vertex n2 = rand() % mv + 1;
    vector<color> colors;

// Complete graph
    cout << "Kn processing...\n";
    fout.open("Kn.out");
    graph Kn; edges EKn;
    graphe_complete(Kn, EKn, n);
    graphe_write(Kn, EKn, fout);
    HamiltonianCycle(Kn, fout);
    HamiltonianCycles(Kn, fout);
    MinimalVertexColoring(Kn, colors, fout);
    MinimalEdgeColoring(Kn, EKn, fout);
    Hierholzer(Kn, EKn, fout);

    graphe_complete(Kn, EKn, n1);
    graphe_write(Kn, EKn, fout);
    HamiltonianCycle(Kn, fout);
    HamiltonianCycles(Kn, fout);
    MinimalVertexColoring(Kn, colors, fout);
    MinimalEdgeColoring(Kn, EKn, fout);
    Hierholzer(Kn, EKn, fout);

    graphe_complete(Kn, EKn, n2);
    graphe_write(Kn, EKn, fout);
    HamiltonianCycle(Kn, fout);
    HamiltonianCycles(Kn, fout);
    MinimalVertexColoring(Kn, colors, fout);
    MinimalEdgeColoring(Kn, EKn, fout);
    Hierholzer(Kn, EKn, fout);
    fout.close();
    cout << "Kn finished...\n";

//  Cycle graph
    cout << "Cn processing...\n";
    fout.open("Cn.out");
    graph Cn; edges ECn;
    graphe_cycle(Cn, ECn, n);
    graphe_write(Cn, ECn, fout);
    HamiltonianCycle(Cn, fout);
    HamiltonianCycles(Cn, fout);
    MinimalVertexColoring(Cn, colors, fout);
    MinimalEdgeColoring(Cn, ECn, fout);
    Hierholzer(Cn, ECn, fout);

    graphe_cycle(Cn, ECn, n1);
    graphe_write(Cn, ECn, fout);
    HamiltonianCycle(Cn, fout);
    HamiltonianCycles(Cn, fout);
    MinimalVertexColoring(Cn, colors, fout);
    MinimalEdgeColoring(Cn, ECn, fout);
    Hierholzer(Cn, ECn, fout);

    graphe_cycle(Cn, ECn, n2);
    graphe_write(Cn, ECn, fout);
    HamiltonianCycle(Cn, fout);
    HamiltonianCycles(Cn, fout);
    MinimalVertexColoring(Cn, colors, fout);
    MinimalEdgeColoring(Cn, ECn, fout);
    Hierholzer(Cn, ECn, fout);
    fout.close();

    cout << "Cn finished\n";
//  Star graph
    cout << "Sn processing...\n";
    fout.open("Sn.out");
    graph Sn; edges ESn;
    graphe_star(Sn, ESn, n);
    graphe_write(Sn, ESn, fout);
    HamiltonianCycle(Sn, fout);
    HamiltonianCycles(Sn, fout);
    MinimalVertexColoring(Sn, colors, fout);
    Hierholzer(Sn, ESn, fout);

    graphe_star(Sn, ESn, n1);
    graphe_write(Sn, ESn, fout);
    HamiltonianCycle(Sn, fout);
    HamiltonianCycles(Sn, fout);
    MinimalVertexColoring(Sn, colors, fout);
    Hierholzer(Sn, ESn, fout);

    graphe_star(Sn, ESn, n2);
    graphe_write(Sn, ESn, fout);
    HamiltonianCycle(Sn, fout);
    HamiltonianCycles(Sn, fout);
    MinimalVertexColoring(Sn, colors, fout);
    Hierholzer(Sn, ESn, fout);
    fout.close();

    cout << "Sn finished\n";
//  Wheel graph
    cout << "Wn finished\n";
    fout.open("Wn.out");
    graph Wn; edges EWn;
    graphe_wheel(Wn, EWn, n);
    graphe_write(Wn, EWn, fout);
    HamiltonianCycle(Wn, fout);
    HamiltonianCycles(Wn, fout);
    MinimalVertexColoring(Wn, colors, fout);
    Hierholzer(Wn, EWn, fout);

    graphe_wheel(Wn, EWn, n1);
    graphe_write(Wn, EWn, fout);
    HamiltonianCycle(Wn, fout);
    HamiltonianCycles(Wn, fout);
    MinimalVertexColoring(Wn, colors, fout);
    Hierholzer(Wn, EWn, fout);

    graphe_wheel(Wn, EWn, n2);
    graphe_write(Wn, EWn, fout);
    HamiltonianCycle(Wn, fout);
    HamiltonianCycles(Wn, fout);
    MinimalVertexColoring(Wn, colors, fout);
    Hierholzer(Wn, EWn, fout);

    fout.close();

    cout << "Wn finished\n";
    //  Complete bipartite graph
    cout << "Kn1_n2 processing...\n";
    fout.open("Kn1_n2.out");
    mv = 5;
    n1 = rand() % mv + 1; n2 = rand() % mv + 1;
    graph Kn1_n2; edges EKn1_n2;
    graphe_bipartite_complete(Kn1_n2, EKn1_n2, n1, n2);
    graphe_write(Kn1_n2, EKn1_n2, fout);
    HamiltonianCycle(Kn1_n2, fout);
    HamiltonianCycles(Kn1_n2, fout);
    MinimalVertexColoring(Kn1_n2, colors, fout);
    MinimalEdgeColoring(Kn1_n2, EKn1_n2, fout);
    Hierholzer(Kn1_n2, EKn1_n2, fout);

    n1 = rand() % mv + 1; n2 = rand() % mv + 1;
    graphe_bipartite_complete(Kn1_n2, EKn1_n2, n1, n2);
    graphe_write(Kn1_n2, EKn1_n2, fout);
    HamiltonianCycle(Kn1_n2, fout);
    HamiltonianCycles(Kn1_n2, fout);
    MinimalVertexColoring(Kn1_n2, colors, fout);
    MinimalEdgeColoring(Kn1_n2, EKn1_n2, fout);
    Hierholzer(Kn1_n2, EKn1_n2, fout);


    n1 = rand() % mv + 1; n2 = rand() % mv + 1;
    graphe_bipartite_complete(Kn1_n2, EKn1_n2, n1, n2);
    graphe_write(Kn1_n2, EKn1_n2, fout);
    HamiltonianCycle(Kn1_n2, fout);
    HamiltonianCycles(Kn1_n2, fout);
    MinimalVertexColoring(Kn1_n2, colors, fout);
    MinimalEdgeColoring(Kn1_n2, EKn1_n2, fout);
    Hierholzer(Kn1_n2, EKn1_n2, fout);

    fout.close();
    cout << "Kn1_n2 finished\n";

    //Knight graph
    cout << "Ktn1_n2 processing...\n";
    fout.open("Ktn1_n2.out");
    graph Ktn1_n2 = graph_knight(3, 10);
    graph_write(Ktn1_n2, fout);
    chessDijkstra(Ktn1_n2, 3, 10, 0, fout);
    HamiltonianCycle(Ktn1_n2, fout);
    HamiltonianCycles(Ktn1_n2, fout);
    MinimalVertexColoring(Kn, colors, fout);
    cout << "Ktn1_n2 finished\n";

    //Other options
    /*Ktn1_n2 = graph_knight(3, 12);
    graph_write(Ktn1_n2, fout);
    HamiltonianCycle(Ktn1_n2, fout);
    Ktn1_n2 = graph_knight(5, 5);
    graph_write(Ktn1_n2, fout);
    HamiltonianCycle(Ktn1_n2, fout);
    Ktn1_n2 = graph_knight(5, 6);
    graph_write(Ktn1_n2, fout);
    HamiltonianCycle(Ktn1_n2, fout);*/
   fout.close();

   //
   // Exercise 19
   //
   // Complete graph

   cout << "WKn processing...\n";
   fout.open("WKn.out");
   wgraph WKn = wgraph_complete(n, 10 );
   wgraph_write(WKn, fout);
   TravellingSalesmanProblem(WKn, fout);
   WKn = wgraph_complete(n1, 10);
   wgraph_write(WKn, fout);
   TravellingSalesmanProblem(WKn, fout);
   WKn = wgraph_complete(n2, 10);
   wgraph_write(WKn, fout);
   TravellingSalesmanProblem(WKn, fout);
   fout.close();
   cout << "WKn finished\n";
   //  Cycle graph
   cout << "WCn processing...\n";
   fout.open("WCn.out");
   wgraph WCn = wgraph_cycle(n, 10);
   wgraph_write(WCn, fout);
   TravellingSalesmanProblem(WCn, fout);
   WCn = wgraph_cycle(n1, 10);
   wgraph_write(WCn, fout);
   TravellingSalesmanProblem(WCn, fout);
   WCn = wgraph_cycle(n2, 10);
   wgraph_write(WCn, fout);
   TravellingSalesmanProblem(WCn, fout);
   fout.close();
   cout << "WCn finished\n";
   //  Star graph
   cout << "WSn processing...\n";
   fout.open("WSn.out");
   wgraph WSn = wgraph_star(n, 10);
   wgraph_write(WSn, fout);
   TravellingSalesmanProblem(WSn, fout);
   WSn = wgraph_star(n1, 10);
   wgraph_write(WSn, fout);
   TravellingSalesmanProblem(WSn, fout);
   WSn = wgraph_star(n2, 10);
   wgraph_write(WSn, fout);
   TravellingSalesmanProblem(WSn, fout);
   fout.close();
   cout << "WSn finished\n";
   //  Wheel graph
   cout << "WWn processing...\n";
   fout.open("WWn.out");
   wgraph WWn = wgraph_wheel(n, 10);
   wgraph_write(WWn, fout);
   TravellingSalesmanProblem(WWn, fout);
   WWn = wgraph_wheel(n1, 10);
   wgraph_write(WWn, fout);
   TravellingSalesmanProblem(WWn, fout);
   WWn = wgraph_wheel(n2, 10);
   wgraph_write(WWn, fout);
   TravellingSalesmanProblem(WWn, fout);
   fout.close();
   cout << "WWn finished\n";

   //  Complete bipartite graph
   cout << "WKn1_n2 processing...\n";
   fout.open("WKn1_n2.out");
   mv = 5;
   n1 = rand() % mv + 1; n2 = rand() % mv + 1;
   wgraph WKn1_n2 = wgraph_completeBipartite(n1, n2, 10);
   wgraph_write(WKn1_n2, fout);
   TravellingSalesmanProblem(WKn1_n2, fout);
   n1 = rand() % mv + 1; n2 = rand() % mv + 1;
   WKn1_n2 = wgraph_completeBipartite(n1, n2, 10);
   wgraph_write(WKn1_n2, fout);
   TravellingSalesmanProblem(WKn1_n2, fout);
   n1 = rand() % mv + 1; n2 = rand() % mv + 1;
   WKn1_n2 = wgraph_completeBipartite(n1, n2, 10);
   wgraph_write(WKn1_n2, fout);
   TravellingSalesmanProblem(WKn1_n2, fout);
   fout.close();
   cout << "WKn1_n2 finished\n";
   //
   // Exercise 20 
   //
   cout << "ciutats processing...\n";
   wgraph ciutats = wgraph_read("cities1.in");
   fout.open("ciutats.out");
   wgraph_write(ciutats, fout);
   TravellingSalesmanProblem(ciutats, fout);
   fout.close();
   cout << "ciutats finished\n";

   //
   // Exercise 21 and 23
   //
   cout << "dodecaheadron processing...\n";
   wgraph WD = wgraph_read("WD.in");
   fout.open("D.out");
   wgraph_write(WD, fout);
   HamiltonianCycles(WD, fout);
   TravellingSalesmanProblem(WD, fout);
   graph D = graph_read("D.in");
   MinimalVertexColoring(D, colors, fout);
   fout.close();
   cout << "dodecaheadron finished\n";

   cout << "isocahedron processing...\n";
   wgraph WI = wgraph_read("WI.in");
   fout.open("I.out");
   wgraph_write(WI, fout);
   HamiltonianCycles(WI, fout);
   TravellingSalesmanProblem(WI, fout);
   graph I = graph_read("I.in");
   MinimalVertexColoring(I, colors, fout);
   fout.close();
   cout << "isocahedron finished\n";

   //
   // Exercise 24
   //
   cout << "comarques processing...\n";
   graph Comarques = graph_read("comarques.in");
   fout.open("comarques.out");
   graph_write(Comarques, fout);
   MinimalVertexColoring(Comarques, colors, fout);
   fout.close();
   cout << "comarques finished\n";

   //
   // Exercise 25 
   //
   cout << "E1 processing...\n";
   graph E1; edges EE1;
   graphe_read(E1, EE1,"E1.in");
   fout.open("E1.out");
   graphe_write(E1, EE1, fout);
   MinimalEdgeColoring(E1, EE1, fout);
   Hierholzer(E1, EE1, fout);
   fout.close();
   cout << "E1 finished\n";

   cout << "E2 processing...\n";
   graph E2; edges EE2;
   graphe_read(E2, EE2, "E2.in");
   fout.open("E2.out");
   graphe_write(E2, EE2, fout);
   MinimalEdgeColoring(E2, EE2, fout);
   Hierholzer(E2, EE2, fout);
   fout.close();
   cout << "E2 finished\n";

   cout << "E3 processing...\n";
   graph E3; edges EE3;
   graphe_read(E3, EE3, "E3.in");
   fout.open("E3.out");
   graphe_write(E3, EE3, fout);
   MinimalEdgeColoring(E3, EE3, fout);
   Hierholzer(E3, EE3, fout);
   fout.close();
   cout << "E3 finished\n";

   cout << "E4 processing...\n";
   graph E4; edges EE4;
   graphe_read(E4, EE4, "E4.in");
   fout.open("E4.out");
   graphe_write(E4, EE4, fout);
   MinimalEdgeColoring(E4, EE4, fout);
   Hierholzer(E4, EE4, fout);
   fout.close();
   cout << "E4 finished\n";

   //
   // EXERCISE 28 
   //
   for (index i = 2; i < 7; i++)
   {
       n = 2 * i;
       cout << "Lliga" << n << " processing...\n";
       char fname[20];
       sprintf_s(fname, "lliga%d.out", n);
       fout.open(fname);
       fout << "S'organitza una lliga de " << n << "equips, de tots contra tots\n";
       fout << "Considerem a cada equip un vertex, i a cada aresta un partit\n";
       fout << "Volem organitzar la lliga de forma que a cada equip jugui un partit cada dia\n";
       fout << "Per aix�, pintem de colors cada aresta (partit) de forma que dos arestes incidents\n";
       fout << "siguin de diferents colors (un equip nom�s juga un partit al dia)\n";
       fout << "intentem trobar el minim de dies (colors) per realitzar la lliga, i com s'organitza\n";
       fout << "Equips:------------\n";
       for (index j = 0; j < n; j++)
           fout << "Equip" << j << endl;
       graph Lliga; edges LligaE;
       graphe_complete(Lliga, LligaE, n);
       graphe_write(Lliga, LligaE, fout);
       MinimalEdgeColoring(Lliga, LligaE, fout);
       fout.close();
       cout << "Lliga" << n << " finished\n";
   }

//
//  Ending
//
    cout << "Press enter to finish..." << endl;
    cin.get();
}
